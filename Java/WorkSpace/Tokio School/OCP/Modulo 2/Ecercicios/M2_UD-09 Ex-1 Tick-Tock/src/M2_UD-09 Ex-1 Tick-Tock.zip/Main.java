/**
 * @author Daniel Gil
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("*** Bem vindo ***");

        TickTock.TickTock();
    }
}